﻿namespace CoffeeShop.Domain.Entities
{
    public class ExtraEntity
    {
        public StaffEntity StaffEntity { get; set; }
    }
}
