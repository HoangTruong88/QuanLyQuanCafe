﻿namespace CoffeeShop.Containts
{
    public class AppsettingConst
    {
        public const string MY_CONNECTION = "MyConnection";
    }
}
