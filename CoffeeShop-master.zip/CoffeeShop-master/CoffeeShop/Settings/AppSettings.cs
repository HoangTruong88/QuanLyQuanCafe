﻿namespace CoffeeShop.Settings
{
    public class AppSettings
    {
        /// <summary>
        /// Database connection string
        /// </summary>
        public string ConnectionStrings { get; set; }
    }
}
